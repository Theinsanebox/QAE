@include('include.header')

<style>
    .input-field-own
    {
        background: transparent;
        color: white;
        border: 1px solid #ffffff6b;
        padding: 10px 20px;
        color: white;
        font-size: 20px;
        width: 90vw;
        height: 300px;
        margin-left: 20px;
        border-radius: 5px;
        margin-top: 40px;
        margin-bottom:20px;
        overflow-y: scroll;
        overflow-x: hidden;
    }

    .input-field-own::-webkit-scrollbar {
    display: none;
    }

    .input-field-btn-own
    {
        height: 45px;
        width: 150px;
        font-size: 25px;
        border-radius: 5px;
        background: #dd2d20;
        color: white;
        margin-left: 20px;
    }
    textarea,button,input
    {
        outline: none;
    }
    .input-field-file-own
    {
        display: block;
        width: 150px;
        height: 45px;
        border: white 3px solid;
        border-radius: 8px;
        color: white;
        background: black;
        margin: 20px;
    }
</style>

<p style="color: white;font-size:1.2cm;font-weight:700;margin-left:20px;margin-top:20px;">Ask the Question Here</p>

<form action="askQuestion" method="POST" enctype="multipart/form-data"> @csrf
    <div>
        <textarea name="question" class="input-field-own" placeholder="Type here something"></textarea>
        <input type="file" name="image" class="input-field-file-own">
        <input type="submit" class="input-field-btn-own">
    </div>
</form>