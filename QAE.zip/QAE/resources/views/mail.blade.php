<style>
    body
    {
        background: #24292e!important;
        color: white;
    }
</style>

<body>
    <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
        <div style="margin:50px auto;width:70%;padding:20px 0">
          <div style="border-bottom:1px solid #eee">
            <a href="" style="font-size:1.4em;color: #ffffff;text-decoration:none;font-weight:600"><strong>Q</strong>uestion <strong>A</strong>nswer <strong>E</strong>xchange</a>
          </div>
          <p style="font-size:1.1em">Hi,</p>
          <p>Use the following OTP to complete your Login procedures. OTP is valid for 30 minutes</p>
          <h2 style="background: #ff1616;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">{{ $otp }}</h2>
          <p style="font-size:0.9em;">Regards,<br /><strong>Q</strong>uestion <strong>A</strong>nswer <strong>E</strong>xchange</p>
          <p>Jainil Soni</p>
          <hr style="border:none;border-top:1px solid #eee" />
          <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
            <p><strong>Q</strong>uestion <strong>A</strong>nswer <strong>E</strong>xchange</p>
          </div>
        </div>
      </div>
</body>