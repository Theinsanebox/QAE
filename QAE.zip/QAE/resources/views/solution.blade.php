@include('include.header')

<style>
    textarea,button,input
    {
        outline: none;
    }

    .qa-inner-container
    {
        border:1px solid grey;
        padding: 20px;
        margin:20px;
    }

    .user-question
    {
        color: white;
        border:1px solid grey;
        padding: 20px;
        margin:20px;
    }

    .user-answers
    {
        color: white;
        border:1px solid grey;
        padding: 20px;
        margin:20px;
    }

    .give-answer
    {
        height: 45px;
        width: 150px;
        font-size: 100%;
        border-radius: 5px;
        background: #dd2d20;
        color: white;
        margin-left: 20px;
        display: block!important;
        margin: 20px 0px;
    }

</style>

<p style="color: white;font-size:1.2cm;font-weight:700;margin-left:20px;margin-top:20px;">Question asked by the users across the QAE Community</p>

<div class="qa-container">
    <div class="qa-inner-container">
        @forelse($allQuestion as $aq)
        <form action="giveAnswer/{{ $aq['id'] }}" method="POST" enctype="multipart/form-data"> @csrf
        <div class="user-question">
            <span><strong> @if($aq['name'] == session('name')) Me @else {{ $aq['name'] }} @endif </strong>:</span> 
            <span style="float:right;">{{ $aq['created_at'] }}</span>
            {{ $aq['question'] }}
            @if(isset($aq->image))
            <img src="public/question/{{ $aq['image'] }}" style="border: 1px solid grey;height:200px;width:200px;margin:10px 0px;">
            @else
            @endif
            <button class="give-answer" onClick="createTextareaEle()">Give a Answer</button>
            @forelse($allAnswer as $aa)
            @if($aa['answerof'] == $aq['id'])
            <div class="user-answers">
                <span><strong>@if($aa['name'] == session('name')) Me @else {{ $aa['name'] }} @endif</strong>:</span>            <span style="float:right;">{{ $aa['created_at'] }}</span>
                {{ $aa['answer'] }}
                <img src="public/answer/{{ $aa['image'] }}" style="border: 1px solid grey;height:200px;width:200px;margin:10px 0px;">
            </div>
            @endif
            @empty
            <div class="user-answers">
                No one answered this question.
            </div>
            @endforelse
        </div>
        </form>
        @empty
        @endforelse
    </div>


</div>





<script>

    function createTextareaEle()
    {
        let ta = document.createElement('textarea');
        let itf = document.createElement('input');
        let sbmt = document.createElement('input');
        ta.style.border = "1px solid grey";
        ta.style.backgroundColor = "transparent";
        ta.style.padding = "20px";
        ta.style.width = "100%";
        ta.style.height = "150px";
        ta.style.margin = "5px";
        ta.style.color = "white";
        itf.type = "file";
        itf.style.position = "relative";
        itf.style.bottom = "50px";
        itf.style.left = "10px";
        sbmt.type = "submit";
        sbmt.value = "Submit";
        sbmt.style.height = "45px";
        sbmt.style.width = "150px";
        sbmt.style.fontSize = "100%";
        sbmt.style.borderRadius = "5px";
        sbmt.style.backgroundColor = "#dd2d20";
        sbmt.style.color = "white";
        sbmt.style.display = "block!important";
        sbmt.style.position = "relative";
        sbmt.style.right = "288px";        

        itf.setAttribute('name','image');
        ta.setAttribute('name','answer');

        document.querySelector('.user-question').appendChild(ta);
        document.querySelector('.user-question').appendChild(itf);
        document.querySelector('.user-question').appendChild(sbmt);
        document.querySelector('.give-answer').disabled = "true";
    }
</script>