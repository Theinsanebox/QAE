<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\qaeusers;
use App\Models\answers;
use App\Models\questions;
use Mail;
use File;

class userController extends Controller
{
    
    function checkLogin(Request $request)
    {
        $query = DB::select("SELECT * FROM `qaeusers` WHERE email='".$request->email."' and password='".$request->password."'");

            if($query)
            {

                session()->put('email',$request->email);
                session()->put('password',$request->password);

                $nameQuey = DB::select("SELECT * FROM `qaeusers` WHERE email='".session('email')."' and password='".session('password')."'");
                $getName = null;

                foreach($nameQuey as $nq2)
                {
                    $getName = $nq2->name;
                }

                session()->put('name',$getName);

                //send Mail

                $otp = rand(1000,9999);

                $otpQuery = DB::table('qaeusers')
                ->where('email',$request->email)
                ->update([
                    'otp' => $otp
                ]);                

                $data = [
                    'otp' => $otp
                ];

                $user = $request->email;

                Mail::send('mail', $data, function($message) use ($user) {
                    $message->to($user);
                    $message->subject('OTP Verification');
                });

                return redirect('otp');
            }
            else
            {

                if($request->email == '' or $request->password == '')
                {
                    session()->flash('blankError','Fill up the Full Detail.');
                }
                else
                {
                    session()->flash('loginError','Login Detail is Invalid.');
                }

                return redirect('');
            }

    }


    function registerUser(Request $request)
    {

        $query = DB::select("SELECT * FROM `qaeusers` WHERE email='".$request->email."'");
        $loopVariable = null;

        foreach($query as $qe)
            {
                $loopVariable = $qe->email;
            }

            if($request->email == '' || $request->name == '' || $request->password == '' || $request->phone == '')
            {

                session()->flash('noInput','Fill up the Full Detail.');

                return redirect('register');
            }
            else
            {
                if($loopVariable)
                {
    
                    session()->flash('alreadyExistEmail',$request->email.' is already exist.');
                    return redirect('register');
                }
                else
                {
    
                    $tableData = new qaeusers;
                    $tableData->name = $request->name;
                    $tableData->email = $request->email;
                    $tableData->phone = $request->phone;
                    $tableData->password = $request->password;
                    $tableData->save();

                    session()->put('email',$request->email);
                    session()->put('password',$request->password);
                    session()->put('name',$request->name);
    
                    return redirect('home');
                }
            }

    }  

    function logoutUser(Request $request)
    {
        if(session()->has('email') and session()->has('password'))
        {
            session()->pull('email');
            session()->pull('password');

            return redirect('');
        }
        else
        {
            return redirect('home');
        }
    }

    function checkOTP(Request $request)
    {

        $query = DB::select("SELECT * FROM `qaeusers` WHERE email='".session('email')."' and otp='".$request->otp."'");

        if($request->otp == '')
        {

            session()->flash('emptyOTP','Enter the OTP');

            return redirect('otp');
        }
        else
        {
            if($query)
            {
                return redirect('home');
            }
            else
            {
    
                session()->flash('otpError','Invalid OTP');
    
                return redirect('otp');
            }
        }

    }


    function askQuestion(Request $request)
    {

        $query = DB::select("SELECT * FROM `qaeusers` WHERE email='".session('email')."' and password='".session('password')."'");
        $name = null;

        foreach($query as $qn)
        {
            $name = $qn->name;
        }

        if(isset($request->image))
        {
            $file = $request->file('image');
            $imageName = rand().".".$file->getClientOriginalExtension();
            $file->move('public/question',$imageName);
    
            $tableData = new questions;
            $tableData->name = $name;
            $tableData->question = $request->question;
            $tableData->image = $imageName;
            $tableData->save();

            return redirect('home');
        }
        else
        {
            $tableData = new questions;
            $tableData->name = $name;
            $tableData->question = $request->question;
            $tableData->image = "noimage";
            $tableData->save();

            return redirect('home');
        }

    }

    function showQNAs()
    {
        $data = questions::all();
        $data2 = answers::all();

        return view('solution',['allQuestion'=>$data,'allAnswer'=>$data2]);
    }

    function giveAnswer(Request $request)
    {
        $findId = questions::find($request->id);

        $query = DB::select("SELECT * FROM `qaeusers` WHERE email='".session('email')."' and password='".session('password')."'");
        $name = null;

        foreach($query as $qn)
        {
            $name = $qn->name;
        }

        if(isset($request->image))
        {
            $file = $request->file('image');
            $imageName = rand().".".$file->getClientOriginalExtension();
            $file->move('public/answer',$imageName);

            $answerTable = new answers;
            $answerTable->name = $name;
            $answerTable->answer = $request->answer;
            $answerTable->image = $imageName;
            $answerTable->answerof = $findId->id;
            $answerTable->save();

            return redirect('solution');
    
        }
        else
        {
            $answerTable = new answers;
            $answerTable->name = $name;
            $answerTable->answer = $request->answer;
            $answerTable->image = "noimage";
            $answerTable->answerof = $findId->id;
            $answerTable->save();

            return redirect('solution');
        }

    }

    //controller ends here

}
