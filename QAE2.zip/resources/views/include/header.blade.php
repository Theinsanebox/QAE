{{-- #24292e --}}
<style>
    body
    {
        background: #24292e!important;
    }
</style>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />


<nav
  class="relative w-full flex flex-wrap items-center justify-between py-3 bg-gray-900 text-gray-200 shadow-lg navbar navbar-expand-lg navbar-light"
>
  <div class="container-fluid w-full flex flex-wrap items-center justify-between px-6">
    <button
      class="navbar-toggler text-gray-200 border-0 hover:shadow-none hover:no-underline py-2 px-2.5 bg-transparent focus:outline-none focus:ring-0 focus:shadow-none focus:no-underline"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#navbarSupportedContent1"
      aria-controls="navbarSupportedContent"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <svg
        aria-hidden="true"
        focusable="false"
        data-prefix="fas"
        data-icon="bars"
        class="w-6"
        role="img"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 448 512"
      >
        <path
          fill="currentColor"
          d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"
        ></path>
      </svg>
    </button>
    <div class="collapse navbar-collapse flex-grow items-center" id="navbarSupportedContent1">
      <img src="{{ URL::asset('public/logo/qae3.png') }}" alt="qae" style="height: 50px;width:50px;margin-right:20px;">
      <a class="text-xl text-white pr-2 font-semibold" href="#"><strong>Q</strong>uestion <strong>A</strong>nswer <strong>E</strong>xchange</a>
      <!-- Left links -->
      <ul class="navbar-nav flex flex-col pl-0 list-style-none mr-auto">
        <li class="nav-item p-2">
          <a class="nav-link text-white" href="home">Home</a>
        </li>

        <li class="nav-item p-2">
            <a class="nav-link text-white" href="solution">Find Solutions</a>
          </li>

          <li class="nav-item p-2">
            <a class="nav-link text-white" href="ask">Ask the Question</a>
          </li>
      </ul>
      <!-- Left links -->
    </div>
    <!-- Collapsible wrapper -->

    <!-- Right elements -->
    <div class="flex items-center relative">
      <a href="setting">
        <svg xmlns="http://www.w3.org/2000/svg" style="height: 30px;width:30px;" x="0px" y="0px"
        width="64" height="64"
        viewBox="0 0 172 172"
        style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M74.61487,0c-4.07791,-0.01286 -7.49573,3.07978 -7.88928,7.13867l-1.71643,17.19055l-7.7738,3.2229l-13.37451,-10.94421c-3.1482,-2.58935 -7.74925,-2.35976 -10.62402,0.53015l-16.09876,16.104c-2.88677,2.87408 -3.11629,7.47145 -0.53015,10.61877l10.95471,13.39026l-3.2124,7.75806l-17.21155,1.72168c-4.05689,0.39337 -7.14882,3.80813 -7.13867,7.88403v22.77026c-0.01015,4.0759 3.08178,7.49067 7.13867,7.88403l17.21155,1.72168l3.2124,7.75806l-10.95471,13.39026c-2.58614,3.14732 -2.35661,7.74469 0.53015,10.61877l16.104,16.10401c2.87293,2.88936 7.47234,3.11899 10.61877,0.53015l13.36926,-10.93896l7.77905,3.21765l1.72168,17.19055c0.39337,4.05689 3.80813,7.14882 7.88403,7.13867h22.77026c4.07791,0.01286 7.49573,-3.07978 7.88928,-7.13867l1.71643,-17.19055l7.77905,-3.2229l13.36926,10.94421c3.14679,2.5936 7.75106,2.36384 10.62402,-0.53015l16.09876,-16.09876c2.88991,-2.87478 3.1195,-7.47582 0.53015,-10.62402l-10.95471,-13.39026l3.2124,-7.75806l17.2168,-1.72168c4.05481,-0.3959 7.14383,-3.80996 7.13342,-7.88403v-22.77026c0.01015,-4.0759 -3.08178,-7.49067 -7.13867,-7.88403l-17.21155,-1.72168l-3.2124,-7.75806l10.95471,-13.39026c2.58614,-3.14732 2.35662,-7.74469 -0.53015,-10.61877l-16.10401,-16.104c-2.8732,-2.88874 -7.47213,-3.11835 -10.61877,-0.53015l-13.39026,10.95471l-7.75806,-3.2124l-1.71643,-17.21155c-0.39356,-4.0589 -3.81137,-7.15153 -7.88928,-7.13867zM74.61487,5.375h22.77026c1.31324,-0.00406 2.41385,0.99195 2.54053,2.29907l1.87915,18.8125c0.09897,0.98418 0.72984,1.83476 1.64295,2.21509l10.729,4.44067c0.9149,0.37766 1.96329,0.22242 2.72949,-0.40417l14.63428,-11.96777c1.01302,-0.83611 2.49609,-0.76332 3.42236,0.16797l16.09875,16.09875c0.93179,0.92606 1.00459,2.40951 0.16797,3.42236l-11.97302,14.63428c-0.62409,0.76755 -0.77724,1.81543 -0.39892,2.72949l4.44067,10.72375c0.37775,0.91598 1.2292,1.54952 2.21509,1.6482l18.8125,1.8844c1.30561,0.12552 2.30143,1.22366 2.29907,2.53528v22.77026c0.00236,1.31162 -0.99347,2.40976 -2.29907,2.53528l-18.8125,1.8844c-0.98467,0.09771 -1.83582,0.72901 -2.21509,1.64295l-4.44067,10.729c-0.37832,0.91406 -0.22517,1.96194 0.39892,2.72949l11.97302,14.63428c0.83662,1.01285 0.76382,2.49631 -0.16797,3.42236l-16.09875,16.09875c-0.9265,0.93079 -2.40917,1.00356 -3.42236,0.16797l-14.61853,-11.95727c-0.7651,-0.62907 -1.81492,-0.78452 -2.72949,-0.40418l-10.74475,4.45117c-0.91363,0.37966 -1.54478,1.2306 -1.64295,2.21509l-1.87915,18.7915c-0.12667,1.30713 -1.22728,2.30313 -2.54053,2.29907h-22.77026c-1.31324,0.00406 -2.41386,-0.99195 -2.54053,-2.29907l-1.87915,-18.7915c-0.09817,-0.98449 -0.72932,-1.83543 -1.64295,-2.21509l-10.75,-4.45117c-0.91475,-0.37888 -1.96379,-0.22354 -2.72949,0.40418l-14.61328,11.95727c-1.01336,0.83508 -2.49565,0.76233 -3.42236,-0.16797l-16.09875,-16.09875c-0.93179,-0.92606 -1.00459,-2.40951 -0.16797,-3.42236l11.97302,-14.63428c0.62409,-0.76755 0.77724,-1.81543 0.39892,-2.72949l-4.44067,-10.72375c-0.37775,-0.91598 -1.2292,-1.54952 -2.21509,-1.6482l-18.8125,-1.8844c-1.30561,-0.12552 -2.30143,-1.22366 -2.29907,-2.53528v-22.77026c-0.00236,-1.31162 0.99347,-2.40976 2.29907,-2.53528l18.8125,-1.8844c0.98467,-0.09771 1.83582,-0.72901 2.21509,-1.64295l4.44067,-10.729c0.37832,-0.91406 0.22517,-1.96194 -0.39892,-2.72949l-11.97302,-14.63428c-0.83662,-1.01285 -0.76382,-2.49631 0.16797,-3.42236l16.09875,-16.09875c0.9265,-0.93079 2.40917,-1.00356 3.42236,-0.16797l14.61853,11.95727c0.76563,0.62788 1.81476,0.78324 2.72949,0.40418l10.74475,-4.45117c0.91363,-0.37966 1.54478,-1.2306 1.64295,-2.21509l1.87915,-18.7915c0.12667,-1.30713 1.22728,-2.30313 2.54053,-2.29907zM86,43c-23.74824,0 -43,19.25176 -43,43c0,23.74824 19.25176,43 43,43c23.74824,0 43,-19.25176 43,-43c-0.0271,-23.73701 -19.26299,-42.9729 -43,-43zM84.43579,48.40649c10.24147,-0.42614 20.21346,3.34462 27.61057,10.44054c7.39711,7.09591 11.57892,16.90264 11.57864,27.15297c-0.0234,20.77001 -16.85499,37.6016 -37.625,37.625c-20.48467,0.01375 -37.21623,-16.36248 -37.64213,-36.84273c-0.4259,-20.48025 15.61039,-37.53791 36.07792,-38.37578z"></path></g></g></svg>
      </a>
        <img src="https://jainilsoni1706.github.io/jass/j144.png" style="height:30px;width:30px;border-radius:50%;margin-left:20px;">
        <a href="logoutUser"><span>&nbsp;&nbsp;&nbsp;<strong>Logout</strong></span></a>
    </div>
</nav>

@include('include.footer')