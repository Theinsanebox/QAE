@include('include.header')

<form action="">

</form>

@include('include.footer')