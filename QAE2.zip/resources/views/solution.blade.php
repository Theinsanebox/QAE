@include('include.header')

<style>
    textarea,button,input
    {
        outline: none;
    }

    .qa-inner-container
    {
        border:1px solid grey;
        padding: 20px;
        margin:20px;
    }

    .user-question
    {
        color: white;
        border:1px solid grey;
        padding: 20px;
        margin:20px;
    }

    .user-answers
    {
        color: white;
        border:1px solid grey;
        padding: 20px;
        margin:20px;
    }

    .give-answer
    {
        height: 45px;
        width: 150px;
        font-size: 100%;
        border-radius: 5px;
        background: #dd2d20;
        color: white;
        margin-left: 20px;
        display: block!important;
        margin: 20px 0px;
    }

</style>

<p style="color: white;font-size:1.2cm;font-weight:700;margin-left:20px;margin-top:20px;">Question asked by the users across the QAE Community</p>

<div class="qa-container">
    <div class="qa-inner-container">
        @forelse($allQuestion as $aq)
        <style>
            .user-question{{ $aq['id'] }}
            {
            color: white;
            border:1px solid grey;
            padding: 20px;
            margin:20px;
            }

            .give-answer{{ $aq['id'] }}
            {
            height: 45px;
            width: 150px;
            font-size: 100%;
            border-radius: 5px;
            background: #dd2d20;
            color: white;
            margin-left: 20px;
            display: block!important;
            margin: 20px 0px;
            }
        </style>
        <form action="giveAnswer/{{ $aq['id'] }}" method="POST" enctype="multipart/form-data"> @csrf
        <div class="user-question{{ $aq['id'] }}">
            <span><strong> @if($aq['name'] == session('name')) Me @else {{ $aq['name'] }} @endif </strong>:</span> 
            <span style="float:right;">{{ $aq['created_at'] }}</span>
            {{ $aq['question'] }}
            @if($aq->image !== "noimage")
            <img src="public/question/{{ $aq['image'] }}" style="border: 1px solid grey;height:200px;width:200px;margin:10px 0px;">
            @else
            @endif
            <button class="give-answer{{ $aq['id'] }}" type="reset" onClick="createTextareaEle{{ $aq['id'] }}()">Give a Answer</button>
            <script>

                function createTextareaEle{{ $aq['id'] }}()
                {
                    let ta{{ $aq['id'] }} = document.createElement('textarea');
                    let itf{{ $aq['id'] }} = document.createElement('input');
                    let sbmt{{ $aq['id'] }} = document.createElement('input');
                    ta{{ $aq['id'] }}.style.border = "1px solid grey";
                    ta{{ $aq['id'] }}.style.backgroundColor = "transparent";
                    ta{{ $aq['id'] }}.style.padding = "20px";
                    ta{{ $aq['id'] }}.style.width = "100%";
                    ta{{ $aq['id'] }}.style.height = "150px";
                    ta{{ $aq['id'] }}.style.margin = "5px";
                    ta{{ $aq['id'] }}.style.color = "white";
                    itf{{ $aq['id'] }}.type = "file";
                    itf{{ $aq['id'] }}.style.position = "relative";
                    itf{{ $aq['id'] }}.style.bottom = "50px";
                    itf{{ $aq['id'] }}.style.left = "10px";
                    sbmt{{ $aq['id'] }}.type = "submit";
                    sbmt{{ $aq['id'] }}.value = "Submit";
                    sbmt{{ $aq['id'] }}.style.height = "45px";
                    sbmt{{ $aq['id'] }}.style.width = "150px";
                    sbmt{{ $aq['id'] }}.style.fontSize = "100%";
                    sbmt{{ $aq['id'] }}.style.borderRadius = "5px";
                    sbmt{{ $aq['id'] }}.style.backgroundColor = "#dd2d20";
                    sbmt{{ $aq['id'] }}.style.color = "white";
                    sbmt{{ $aq['id'] }}.style.display = "block!important";
                    sbmt{{ $aq['id'] }}.style.position = "relative";
                    sbmt{{ $aq['id'] }}.style.right = "288px";        
            
                    itf{{ $aq['id'] }}.setAttribute('name','image');
                    ta{{ $aq['id'] }}.setAttribute('name','answer');
            
                    document.querySelector('.user-question{{ $aq['id'] }}').appendChild(ta{{ $aq['id'] }});
                    document.querySelector('.user-question{{ $aq['id'] }}').appendChild(itf{{ $aq['id'] }});
                    document.querySelector('.user-question{{ $aq['id'] }}').appendChild(sbmt{{ $aq['id'] }});
                    document.querySelector('.give-answer{{ $aq['id'] }}').disabled = "true";
            
                }
            </script>
            @forelse($allAnswer as $aa)
            @if($aa['answerof'] == $aq['id'])
            <div class="user-answers">
                <span><strong>@if($aa['name'] == session('name')) Me @else {{ $aa['name'] }} @endif</strong>:</span>            <span style="float:right;">{{ $aa['created_at'] }}</span>
                {{ $aa['answer'] }}
                @if($aa['image'] !== "noimage")
                <img src="public/answer/{{ $aa['image'] }}" style="border: 1px solid grey;height:200px;width:200px;margin:10px 0px;">
                @else
                @endif
            </div>
            @endif
            @empty
            <div class="user-answers">
                No one answered this question.
            </div>
            @endforelse
        </div>
        </form>
        @empty
        @endforelse
    </div>


</div>





