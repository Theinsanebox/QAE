<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\userController;

Route::get('/', function () {
    return view('login');
});

Route::view('ask','ask');
Route::view('home','home');
Route::view('register','register');
Route::view('otp','otp');
Route::view('setting','setting');
Route::view('solution','solution');

Route::post('checkLogin',[userController::class,'checkLogin']);
Route::post('registerUser',[userController::class,'registerUser']);
Route::post('checkOTP',[userController::class,'checkOTP']);
Route::post('askQuestion',[userController::class,'askQuestion']);
Route::post('giveAnswer/{id}',[userController::class,'giveAnswer']);

Route::get('solution',[userController::class,'showQNAs']);
Route::get('logoutUser',[userController::class,'logoutUser']);

